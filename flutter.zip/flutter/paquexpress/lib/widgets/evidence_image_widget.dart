import 'dart:convert';
import 'package:flutter/material.dart';

class EvidenceImageWidget extends StatelessWidget {
  final String base64Image;
  final double? width;
  final double? height;

  const EvidenceImageWidget({
    Key? key,
    required this.base64Image,
    this.width,
    this.height,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Para Flutter Web, usar data URL
    final dataUrl = 'data:image/jpeg;base64,$base64Image';
    
    return Image.network(
      dataUrl,
      width: width,
      height: height,
      fit: BoxFit.cover,
      loadingBuilder: (context, child, loadingProgress) {
        if (loadingProgress == null) return child;
        return Center(
          child: CircularProgressIndicator(
            value: loadingProgress.expectedTotalBytes != null
                ? loadingProgress.cumulativeBytesLoaded /
                    loadingProgress.expectedTotalBytes!
                : null,
          ),
        );
      },
      errorBuilder: (context, error, stackTrace) {
        return Container(
          width: width,
          height: height,
          color: Colors.grey[300],
          child: Icon(
            Icons.broken_image,
            size: 40,
            color: Colors.grey[500],
          ),
        );
      },
    );
  }
}