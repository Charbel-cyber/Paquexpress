import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker_web/image_picker_web.dart';
import 'dart:convert';
import 'evidence_image_widget.dart';

class ImageCaptureWeb extends StatefulWidget {
  final Function(String) onImageSelected;
  
  const ImageCaptureWeb({Key? key, required this.onImageSelected}) : super(key: key);

  @override
  _ImageCaptureWebState createState() => _ImageCaptureWebState();
}

class _ImageCaptureWebState extends State<ImageCaptureWeb> {
  Uint8List? _imageBytes;
  String? _base64Image;

  Future<void> _pickImage() async {
    try {
      final image = await ImagePickerWeb.getImageAsBytes();
      
      if (image != null) {
        setState(() {
          _imageBytes = image;
          _base64Image = base64Encode(image);
        });
        
        widget.onImageSelected(_base64Image!);
      }
    } catch (e) {
      print('Error picking image: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al seleccionar imagen: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        if (_imageBytes != null)
          Container(
            width: 200,
            height: 200,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(10),
            ),
            child: EvidenceImageWidget(base64Image: _base64Image!),
          )
        else
          Container(
            width: 200,
            height: 200,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Center(
              child: Icon(Icons.photo_camera, size: 50, color: Colors.grey),
            ),
          ),
        
        SizedBox(height: 10),
        
        ElevatedButton.icon(
          onPressed: _pickImage,
          icon: Icon(Icons.camera_alt),
          label: Text('Tomar/Seleccionar Foto'),
        ),
      ],
    );
  }
}