import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io';
import 'main.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List paquetes = [];
  int? paqueteSeleccionado;
  XFile? imagen;
  Position? posicion;

  @override
  void initState() {
    super.initState();
    cargarPaquetes();
  }

  Future<void> cargarPaquetes() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString("token");

    final url = Uri.parse("$API_BASE/paquetes");
    final response = await http.get(
      url,
      headers: {"Authorization": "Bearer $token"},
    );

    if (response.statusCode == 200) {
      setState(() {
        paquetes = json.decode(response.body);
      });
    }
  }

  Future<void> tomarFoto() async {
    final picker = ImagePicker();
    imagen = await picker.pickImage(source: ImageSource.camera);
    setState(() {});
  }

  Future<void> obtenerGPS() async {
    bool servicios = await Geolocator.isLocationServiceEnabled();
    if (!servicios) return;

    LocationPermission permiso = await Geolocator.requestPermission();
    if (permiso == LocationPermission.denied) return;

    posicion = await Geolocator.getCurrentPosition();
    setState(() {});
  }

  Future<void> enviarEntrega() async {
    if (paqueteSeleccionado == null || imagen == null || posicion == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Completa todos los campos")),
      );
      return;
    }

    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString("token");

    final bytes = await File(imagen!.path).readAsBytes();
    final img64 = base64Encode(bytes);

    final url = Uri.parse("$API_BASE/deliver");
    final response = await http.post(
      url,
      headers: {
        "Authorization": "Bearer $token",
        "Content-Type": "application/json",
      },
      body: jsonEncode({
        "package_id": paqueteSeleccionado,
        "latitude": posicion!.latitude,
        "longitude": posicion!.longitude,
        "image_base64": img64,
      }),
    );

    if (response.statusCode == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Entrega registrada")),
      );

      imagen = null;
      posicion = null;
      paqueteSeleccionado = null;
      cargarPaquetes();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Entregas")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Paquetes
              const Text("Paquetes disponibles:"),
              DropdownButton<int>(
                value: paqueteSeleccionado,
                hint: const Text("Selecciona un paquete"),
                items: paquetes.map<DropdownMenuItem<int>>((p) {
                  return DropdownMenuItem<int>(
                    value: p["id"] as int,
                    child: Text("Paquete #${p["id"]}"),
                  );
                }).toList(),
                onChanged: (v) => setState(() => paqueteSeleccionado = v),
              ),

              const SizedBox(height: 20),
              
              // Foto
              ElevatedButton(
                onPressed: tomarFoto,
                child: const Text("Tomar Foto"),
              ),
              if (imagen != null) 
                Image.file(File(imagen!.path), height: 150),

              const SizedBox(height: 20),
              
              // GPS
              ElevatedButton(
                onPressed: obtenerGPS,
                child: const Text("Obtener GPS"),
              ),
              if (posicion != null)
                Text("Lat: ${posicion!.latitude}, Lng: ${posicion!.longitude}"),

              const SizedBox(height: 30),
              
              // Enviar
              ElevatedButton(
                onPressed: enviarEntrega,
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                ),
                child: const Text("Registrar Entrega"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}