import 'dart:convert';
import 'package:http/http.dart' as http;

class DeliveryService {
  final String baseUrl = 'http://127.0.0.1:8000'; // Cambia por tu URL

  Future<bool> registerDelivery({
    required String token,
    required int packageId,
    required double latitude,
    required double longitude,
    required String imageBase64,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/deliver'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'package_id': packageId,
          'latitude': latitude,
          'longitude': longitude,
          'image_base64': imageBase64,
        }),
      );

      return response.statusCode == 200;
    } catch (e) {
      print('Exception: $e');
      return false;
    }
  }

  // Otros métodos relacionados con entregas...
}