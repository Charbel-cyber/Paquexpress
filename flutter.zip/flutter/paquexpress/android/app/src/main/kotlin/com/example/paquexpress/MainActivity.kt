package com.example.paquexpress

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
